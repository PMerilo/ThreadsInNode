#!/bin/sh

stripe postinstall

